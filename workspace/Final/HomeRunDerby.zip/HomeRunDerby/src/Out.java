public class Out extends Swing
{
	public Out(int pitchCount)
	{
		super(pitchCount);
	}

	public String toString() { return "An Out"; }
}
