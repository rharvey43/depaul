public abstract class Swing
{
	private int swingCount = 0;
	
	public Swing(int pitchCount) { swingCount = pitchCount; }

	public int getSwingCount() { return swingCount; }
}
