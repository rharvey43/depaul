public class HomeRun extends Swing
{
	public HomeRun(int pitchCount) 
	{
		super(pitchCount);
	}

	public String toString() { return "A HomeRun"; }
}
