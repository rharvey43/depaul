public enum BeverageItem
{
	SODA,
	ICE,
	FLAVOR
}
