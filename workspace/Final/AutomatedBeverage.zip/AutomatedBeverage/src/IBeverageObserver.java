import java.util.ArrayList;

public interface IBeverageObserver
{
	public void beverage(ArrayList<BeverageItem> beverage);
}
      