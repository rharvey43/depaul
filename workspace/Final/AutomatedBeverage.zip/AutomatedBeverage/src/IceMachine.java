public class IceMachine extends Automation
{
	@Override
	public void processInput()
	{
		System.out.print("[Ice]");
		super.processInput();
	}
}