public class SodaMachine extends Automation
{
	@Override
	public void processInput()
	{
		System.out.print("[Soda]");
		super.processInput();
	}
}