public class FlavorMachine extends Automation
{
	
	
	@Override
	public void processInput()
	{
		System.out.print("[Flavor]");
		super.processInput();
	}
}