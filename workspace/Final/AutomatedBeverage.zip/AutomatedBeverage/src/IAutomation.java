public interface IAutomation
{
	void processInput();
	void setOutput(IAutomation IAutomation);
	IAutomation getOutput();
}
